# HSBC customer integration prototype: synthetic source dataset

This package contains **synthetic test data only**. It was designed from the 24-entity logical model supplied for Section 2.3. No real HSBC customer, account, KYC or AML data is included. All email addresses use the reserved `example.test` domain.

The files provide **source inputs**, not pre-computed Silver or Gold results. Your SQL should create `SOURCE_CUSTOMER_RECORD`, `CUSTOMER_MASTER`, matches, cases, quality issues, lineage records, and reporting tables from these inputs.

## Files and intended use

| File | Rows | Use |
|---|---:|---|
| `source_system.csv` | 3 | Seed `SOURCE_SYSTEM` with CRM, LEND and AMLKYC. |
| `ingestion_batch.csv` | 6 | Seed `INGESTION_BATCH`: initial and second loads for each source. |
| `raw_crm_customer.csv` | 13 | Bronze CRM customer rows, including batch 2 insert, update and delete. |
| `raw_lending_customer.csv` | 6 | Bronze lending customer rows. |
| `raw_aml_kyc_customer.csv` | 9 | Bronze AML/KYC customer rows. |
| `raw_banking_account_snapshot.csv` | 17 | Bronze CRM account snapshots for two reporting dates. |
| `raw_loan_snapshot.csv` | 12 | Bronze lending loan snapshots for two reporting dates. |
| `raw_account_transaction.csv` | 16 | Bronze account transaction events. |
| `raw_kyc_verification.csv` | 9 | Bronze KYC verification events. |
| `raw_aml_screening.csv` | 10 | Bronze AML screening events, including a potential match in batch 2. |
| `cdc_change_event.csv` | 19 | Seed or stage simulated `CDC_CHANGE_EVENT` rows corresponding to batch 2 source changes. |
| `base_people.csv` | 14 | **Generation reference only. Do not import into Bronze/Silver/Gold.** |
| `expected_identity_map.csv` | 14 | **Answer key only. Do not use as a matching input.** |
| `hsbc_synthetic_source_data.xlsx` | — | Review copy containing the same CSV data in separate sheets. |

The number of source rows represented by each ingestion batch is recorded in `ingestion_batch.csv` as `records_received` and `records_processed`. A batch includes rows from all Bronze files owned by that source, not just customer rows.

## Load sequence

1. Create the three source systems and six ingestion batches.
2. Load all `B1-*` rows into separate Bronze tables for CRM, Lending and AML/KYC. Keep each file's source-specific fields and `bronze_record_reference`.
3. Run your standardisation, data quality and matching SQL. Do not load `base_people.csv` or `expected_identity_map.csv` into the integration pipeline.
4. Record the 2026-09-01 reporting snapshot if your Gold SQL supports historical snapshots.
5. Load all `B2-*` Bronze rows and `cdc_change_event.csv` in source event order. Apply update, insert and delete semantics; retain previous versions in Silver.
6. Refresh Gold for 2026-09-15, then compare results with the test scenarios below.

Dates and timestamps use ISO format. Financial values are in **AUD**. Account balances, loan balances, income and cost values are supplied as dated source snapshots; account transactions are separate events and should not automatically be treated as income.

## Test scenarios

| Person in answer key | Source evidence | Expected behaviour to test |
|---|---|---|
| P001 | CRM-001, LEND-001, KYC-001 | Three source customer identifiers should resolve to one customer. Lending uses `WONG, ALICE`, requiring name standardisation. |
| P002 | CRM-002 and LEND-002 | Date of birth differs (`1988-04-11` vs `1988-04-17`). Send the proposed match to review; do not silently accept a conflicting identity. |
| P003 | CRM-003 and KYC-003 | CRM has an older address. Verified KYC contains the preferred address. Record which source supplied the selected address. |
| P004 | CRM-004 and KYC-004 | KYC status is `MISSING_DOCUMENT`; generate a quality issue and a reportable verification case if your rules require it. |
| P005 | CRM-005, LEND-005 and KYC-005 | One account has a negative balance. A new batch 2 screening row is a `POTENTIAL_MATCH`; it may trigger an AML case, but is not a confirmed AML finding. |
| P006 | CRM-006 and KYC-006 | CRM email changes in batch 2. Close the prior source version, apply survivorship rules, and retain provenance and history. |
| P007 | CRM-007 | A batch 2 `D` event closes the current CRM source version. Preserve the original Bronze and Silver history. Decide whether the golden identity remains inactive according to your rules. |
| P008 | LEND-008 | Lending-only customer must still be eligible for an integrated customer identity. |
| P009 | KYC-009 | AML/KYC-only customer tests a customer with no CRM or lending record. |
| P010 | CRM-010, LEND-010 and KYC-010 | Second straightforward three-source match. |
| P011 | CRM-011 | New CRM customer appears only in batch 2. |
| P012 | CRM-012, LEND-012 and KYC-012 | KYC verification expired before the first reporting date; should be visible in a KYC exception report. |
| P013 | CRM-013 | CRM-only customer. |
| P014 | KYC-014 | AML/KYC-only customer. |

`person_id` is an answer-key identifier used to design the synthetic data. It must **not** be used as a cross-system matching key in your SQL. Match on source attributes under your stated rules, and preserve `source_customer_reference` for lineage.

## Simulated CDC conventions

- `I`, `U` and `D` mean insert, update and delete.
- `source_entity_name` distinguishes CUSTOMER, ACCOUNT, LOAN and AML_SCREENING.
- `event_sequence` is unique within each `(source_system_id, source_entity_name)` stream in this sample.
- `change_payload` contains the matching immutable Bronze row reference. The Bronze row itself contains the source values.
- `D` is a tombstone event; it closes the current source version and should not erase historical evidence.
- Batch 2 account and loan snapshots are source changes, so each has a matching simulated CDC event.

## Prototype boundaries

The raw source file layouts are illustrative Bronze structures. They intentionally differ from the normalised Silver tables in the DBML. These files contain no pre-generated customer master IDs, match decisions, AML cases, risk assessments, data quality issues, lineage edges or Gold facts. Those outputs should be produced and checked by your SQL so the demonstration shows the integration process.
